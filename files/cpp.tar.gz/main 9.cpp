#include <iostream>
#include <cmath>
using namespace std;

int main()
{
   int n, i=1,suma=0,p;
    cout << "Podaj dowolna liczbe" << endl;
    cin>>n;
    p=sqrt(n)
    while (i<=sqrt(n)
    {
        if (n%i==0)
            suma+=i+(n/i);
            i++;

    }
    if (p==sqrt(n))
    if (suma==n)
        cout<<"Liczba jest doskonala"<<endl;
    else
        cout<<"Liczba nie jest doskonala"<<endl;
    return 0;
}
