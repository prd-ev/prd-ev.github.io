#include <iostream>

using namespace std;

int main()
{
int a ,b,c ;
cout << "podaj 3 liczby: "<<endl ;
cin  >> a;
cin  >> b;
cin  >> c;



{
   /* if (a>b&&a>c)
    {if(a<b+c)
      cout << "trórj¹t istnieje";
      else cout<< " nie istnieje";}
      else
      {
        if (b>a&&b>c)
          {if(b<a+c)
          cout << "trórj¹t istnieje";

          else
            cout<< " nie istnieje";}}
{if (c>b &&c>a)
    {
        if (c<a+b)
            cout <<"istnieje" ;
        else
            cout <<"nie istnieje";
    }
}
}}*/


{if (a+b>c&&a+c>b&&b+c>a)
     cout << "Istnieje " ;
     else
     cout << "Trójkąt nie istnieje " ;




}











}






    return 0;
}
