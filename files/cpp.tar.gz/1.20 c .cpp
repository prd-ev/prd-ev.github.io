#include <iostream>

using namespace std;

int main()
{
    cout << "Podaj n" << endl;
    int i,n,x=-10,s=0;
    cin >> n;


    for(i=1;i<=n;i++)
    {
        s=s+x;
        x=x+6;
    }
    cout << s;















    return 0;
}
