//Do��cz do programu plikji iostream i string
#include <iostream>
#include <string>

//Nie trzeba wpisywa� std przed operacjami pliku iostream
using namespace std;

//Rozpocznij program
int main()
{
    //Wypisz komunikat Jak masz na imi�

    cout << "Jak masz na imie: " << endl;

    //zdeklaruj zmienn� typu string o nazwie imie
    string imie;
    //Czytaj imie
    cin >> imie;

    //Wy�wietl komunikat ile masz lat
    cout << "Ile masz lat: " << endl;
    //zadeklaruj zmienn� typu int o nazwie wiek
    int wiek;
    //Czytaj wiek
    cin >> wiek;
    //Wypisz komunikat witaj imie nie wiedzia�em �e mnsz wiek lat
    cout << "Witaj " << imie << "!\nNie wiedzialem, �e masz " << wiek << " lat!";
    //Zako�cz program
    return 0;
}
