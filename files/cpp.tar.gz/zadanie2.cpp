#include <iostream>

using namespace std;

int main()
{
    int n, suma = 0;
    cin >> n;

    for(int i = 1; i <= n; i++)
    {
        if(i % 100 == 31 || i % 100 == 62 || i % 100 == 17)
        suma += i;
    }

    cout << suma;

    return 0;
}
