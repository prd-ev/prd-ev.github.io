#include<iostream>
using namespace std;
int main()
{
    double n,i,suma=0,q,w;
    int silnia;
    cin>>n;
    silnia=1;
    i = 1;
    while (i<=n)
    {
        i = 1;
        while (i<=n)
        {
            silnia = silnia*i;
            if (silnia%2 == 0)
            {
                silnia = silnia*-1;
            }
            suma = suma+silnia;
            i = i+1;
        }
    i = i+1;
    }
    q = -0.2;
    while (q<=n)
    {
        q = q+0.3;
    }
    w = suma/q;
    cout<<w;
}
