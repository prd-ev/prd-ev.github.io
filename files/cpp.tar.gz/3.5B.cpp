#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{

int a,b,c;
srand(time(NULL));
a=rand()%(1001) ;
cout << "a= " <<a ;
srand(time(NULL));
b=rand()%(1001) ;
cout << "b= " <<b ;
srand(time(NULL));
c=+ rand()%(1001) ;
cout << "c= " <<c ;





    return 0;
}
