#include <iostream>

using namespace std;

int main()
{
    int s=1, n, i=0,k=1;
    cout << "podaj n" << endl;
    cin  >> n ;

   while(i<n)
    {
    i++;
    s=s*k;
    k=k*(-2);

  cout << k<<endl;
    }
 cout<<"Iloczyn: " << s;






















    return 0;
}
