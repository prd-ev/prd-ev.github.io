#include <iostream>

using namespace std;
int x,y,z,n,j;
int main()
{
    cout << "Podaj liczbe > 0: " << endl;
    cin  >> n;
    x=n/1000;

    y=n/100;

    z=n/10;

    j=n;

    cout << "Tysiace "    << x <<endl;
    cout << "Setki "      << y <<endl;
    cout << "Dziesiatki " << z <<endl;
    cout << "Jednosci "   << j <<endl;
    return 0;
}
