#include <iostream>

using namespace std;

int T[100];

int main()
{
    int n, i = 0;
    cin >> n;

    while(n!=0)
    {
        T[i] = n % 2;
        n /= 2;
        i++;
    }

    i--;

    while(i>=0)
    {
        cout << T[i];
        i--;
    }

    return 0;
}
