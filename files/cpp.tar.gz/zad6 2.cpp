#include<iostream>
using namespace std;
int main()
{
    int n,ilo=0,suma=0,sumaw=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        int m=i;
        while (m>=1)
        {
            suma=suma+m%10;
            m=m/10;
        }
        for (int k=1;k<=suma;k++)
        {
            if (suma%k==0)
            {
                ilo=ilo+1;
            }
        }
        if (ilo==2)
        {
            sumaw=sumaw+i;
        }
        ilo=0;
    }
    cout<<sumaw;
}
