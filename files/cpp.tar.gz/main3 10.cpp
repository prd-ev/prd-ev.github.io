#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
    int a,s=0,max=0;
    srand(time(NULL));
    do
    {
        a=2+rand()%49;
        cout<<"a="<<a<<endl;
        s+=a;
        if (a>max) max=a;
    }
    while (a%7);
    cout<<"max="<<max<<endl;
    cout<<"suma="<<s<<endl;
    return 0;
}
