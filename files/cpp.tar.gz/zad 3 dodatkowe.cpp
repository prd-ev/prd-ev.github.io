#include<iostream>
using namespace std;
int main()
{
	double x=100,y=10,z=20,n=35,wynik=0,w2,w1,pro,i,s1,koniec;
	w1 = x/y;
	w2 = x-w1;
	pro = (w2/z)/12;
	i = n*12;
	while (i>=1)
	{
		wynik=wynik+(pro*i);
		i-=1;
	}
	s1=w2*(n*12); 
	koniec=wynik+s1;
	cout<<koniec;
		
}
    