#include <iostream>

using namespace std;

int main()
{
    for (int i=32; i < 256; i += 4)

    {

    cout << "| " << (char) (i) << " == " << i << " | ";
    cout << (char) (i + 1) << " == " << i + 1 << " | ";
    cout << (char) (i + 2) << " == " << i + 2 << " | ";
    cout << (char) (i + 3) << " == " << i + 3 << " | ";
    cout << endl;
    }

    return 0;
}
