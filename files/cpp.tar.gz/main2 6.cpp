#include <iostream>

using namespace std;

int main()
{
  int n;
  cin >> n;

  for(int row = 0; row < n; row++) {
    for(int col = 0; col < n; col++) {
      bool isCenter = (row == n/2 && col == n/2);
      bool isBorder = (col == 0 || col == n - 1 || row == 0 || row == n - 1);
      if(isBorder || isCenter) {
        cout << "*";
      } else {
        cout << " ";
      }
      cout << " ";
    }
    cout << "\n";
  }
  return 0;
}
