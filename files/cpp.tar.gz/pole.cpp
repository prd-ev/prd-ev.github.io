#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    const double  pi=3.14;
    float h , r , c ;
    cout << "podaj h i r" << endl;
    cin >>  h ;
    cin >>  r  ;
    c=r*r*pi*h ;
    cout << "pole = " << c ;
    return 0;
}
