#include <iostream>

using namespace std;
int wiek ;
string imie ;
int main()
{
    cout << "Jak masz na imie? " << endl;
    cin  >> imie ;
    cout << "Ile masz lat? " << endl;
    cin  >> wiek ;
    cout << "witaj " << imie << "!"<< endl;
    cout << "Nie wiedzialem, ze masz " << wiek << " lat" << endl;







    return 0;
}
