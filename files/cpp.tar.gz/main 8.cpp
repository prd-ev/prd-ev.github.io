#include <iostream>

using namespace std;

int main()
{
    int n,s=0, k;
    cout << "Podaj n" << endl;
    cin>>n;

    for (int i=1; i<=n; i++)
    {
        k=i;
        for (int x=2; x<k; x++)
        {
            if (k%i==0)
            {
                x++;
            }
            else
                i++;

            if (i==k)
               s+=k;
        }
    }
    cout<<"Suma wynosi: "<<s<<endl;
    return 0;
}
