#include<iostream>
using namespace std;
int main()
{
    string a="*",d="$$";
    int k=1,i=3;
    while (k <= 3)
    {
        cout<<a;
        a=a+"*";
        if (k==1)
        {
            cout<<"|||";
        }
        else if (k==2)
        {
            cout<<"||";
        }
        else
        {
            cout<<"|";
        }
        if (d=="$$$$")
        {
            cout<<d;
            d="$$";
        }
        else
        {
            cout<<d;
            d=d+"$$";
        }
        k=k+1;
    }












}

