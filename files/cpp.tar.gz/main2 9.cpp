#include <iostream>

using namespace std;

int main()
{
    float liczba;
    cin >> liczba;
    liczba = 1/liczba;
    cout << "Odwrotno�� wynosi " << liczba;
    return 0;
}
