#include <iostream>

int main()
{

    int liczba;
    std::cout << "Podaj liczbe: ";
    std::cin >> liczba;

    if (liczba % 2 == 0)
    {
        std::cout << "Liczba parzysta";
    }
    else
    {
        std::cout << "Liczba nieparzysta";
    }

    return 0;
}
