#include<iostream>
using namespace std;
int main()
{
    int n,i, l;
    float liczba;
    cin>>n;
    l = n;
    for (i=1;i<=n;i=i+1)
    {
        l=l+i;
    }
    liczba = 2*n/l;
    cout<<liczba;
}
