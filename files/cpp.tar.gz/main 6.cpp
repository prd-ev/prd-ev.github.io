#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int n, i=1,suma=0;
    cout << "Podaj dowolna liczbe" << endl;
    cin>>n;

    while (i<=n)
    {
        if (n%i==0)
            suma+=i;
            i++;

    }
    if (suma==n)
        cout<<"Liczba jest doskonala"<<endl;
    else
        cout<<"Liczba nie jest doskonala"<<endl;
    return 0;
}
