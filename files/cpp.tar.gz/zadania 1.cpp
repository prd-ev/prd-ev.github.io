#include <iostream>

int main()
{

    float liczba;
    std::cout << "Podaj liczbe: ";
    std::cin >> liczba;

    if (liczba >= 0)
    {
        std::cout << liczba;
    }
    else
    {
        std::cout << -liczba;
    }

    return 0;
}
