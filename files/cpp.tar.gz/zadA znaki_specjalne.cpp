#include <iostream>

using namespace std;
int c,d;
int main()
{
int a=5;
int b=3;

   cout << "\"tekst\" \"tekst\"\n" ;//wyświetlenie  ”tekst” znak spacji  ”tekst” ,znak przejścia do kolejnego wiersza
   cout <<  "\ttekst1" "\ttekst2\ntekst3\n" ;
   cout << "\na=" << a << "\nb=" << b ;
   cout << "\nsuma 8\n";
   cout << "Podaj dwie liczby\n";
   cin  >> c >> d;
   cout << "suma " << c+d;

	//wyświetlenie  tekst1 znak tabulatora poziomego tekst2 znak przejścia do kolejnego wiersza tekst3


	//zadeklarowanie zmiennych a i b typu całkowitego i przypisanie im odpowiednio wartości 5 i 3


	//wyświetlenie w osobnych wierszach a, b i sumy


	//zadeklarowanie zmiennych c i d typu całkowitego


	//wyświetlenie tekstu Podaj dwie liczby


	//wczytanie wartości dla zmiennych c i d


	//wyświetlenie w osobnych wierszach c, d i sumy


    return 0;
}
