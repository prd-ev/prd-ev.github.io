#include <iostream>
using namespace std;
int main()
{


    cout<<"Podaj n ";
    int a=1,n;
    cin>>n;
    double s;
    while(a<=n)
    {
        s=s+1/(2.*a);
        a=a+1;
    }
    cout<<"Suma wynosi "<<s<<endl;
    return 0;
}
