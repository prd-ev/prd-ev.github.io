#include<iostream>
using namespace std;
int main()
{
    int n,i,suma=0,silnia;
    cin>>n;
    silnia=1;
    i = 1;
    while (i<=n)
    {
        i = 1;
        while (i<=n)
        {
            silnia = silnia*i;
            suma = suma + silnia;
            i = i+1;
        }
    i = i+1;
    }
    cout<<suma;

}
