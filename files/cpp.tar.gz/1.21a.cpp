#include <iostream>
using namespace std;
int main()
{

    cout<<"Podaj n ";
    int n,s=0,x=1;
    cin>>n;
    while(x<=n)
    {
        s=s+x;
        x=x+1;
    }
    cout<<"Twoj wynik to: "<<2.*n/s;
    return 0;
}
