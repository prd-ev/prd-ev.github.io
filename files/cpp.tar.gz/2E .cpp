#include <iostream>

using namespace std;
int c,d;
int main()
{
int a=5;
int b=3;

   cout << "\"tekst\" \"tekst\"\n" ;
   cout <<  "\ttekst1" "\ttekst2\ntekst3\n" ;
   cout << "\na=" << a << "\nb=" << b ;
   cout << "\nsuma 8\n";
   cout << "Podaj dwie liczby\n";
   cin  >> c >> d;
   cout << "suma " << c+d;



    return 0;
}
