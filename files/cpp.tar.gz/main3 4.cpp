#include <iostream>

using namespace std;

int main()
{
    int a,b,c;
    cout << "Podaj 2 liczby dodatnie:" << endl;
    cin  >> a;
    cin  >> b;
    while(b>0)
    {
        c=a%b;
        a=b;
        b=c;
    }
    cout << "Nwd tych liczb to: " << a;


    return 0;
}
