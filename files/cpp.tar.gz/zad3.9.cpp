#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{

double x;
int n;
cout << "podaj x";
cin >> x;
cout << "Podaj liczbe: ";
cin >> n;
switch (n)
{
    case 1: cout << sqrt(2*x)  ; break;
    case 2: cout << pow(x,2)-5 ; break;
    case 3: cout << cos(x)+1   ; break;
    default:cout << 1;
}





    return 0;
}
