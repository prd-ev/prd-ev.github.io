#include<iostream>
using namespace std;
int main()
{
    string a="*",b="|",c="--";
    int k=1;
    while (k <= 5)
    {
        cout<<a;
        if (k%2!=0)
        {
            cout<<b;
            b=b+"||";
        }
        else
        {
            cout<<c;
            c=c+c;
        }
        k++;
    }
}
