#include <iostream>

using namespace std;

int main()

{


    int s1=0,s2=1,k1=2,k2=3,i=1,n;
    cout << "We ziomek podaj liczbe: ";
    cin   >> n;

{


 do
       {if (i%2!=0)
   {
       s1-=k1;
       s2*=k2;
          }
   else
   {
       s1+=k1;
       s2*=-k2;
   }}
    while (i<=n);
    cout << "wynik = " << (double)s1/s2<<endl;
       }


    return 0;
}
