#include<iostream>
using namespace std;
int main()
{
    int i=-4;
    while (i <= 14)
    {
        cout<< i <<",";
        i = i + 3;
    }
}
