#include <iostream>

using namespace std;
int x, h, m, s;
int main()
{
    cout << "podaj liczbe sekund: " << endl;
    cin >>  x ;
    h=x/3600 ;
    x=x%3600;
   cout << x;
    m=x/60;
    s=x%60 ;
    cout << h <<endl;
    cout << m <<endl;
    cout << s <<endl;








    return 0;
}
