#include <iostream>

using namespace std;

int main()
{
    int x=1,y=1,k=1,z,n;
    cout << "podaj n: " << endl;
    cin  >> n;

    if(n>=1)
    cout<<x;
    if(n>=2)
    cout<<x;
    k=3;
    while (k<=n)
    {
        z=x+y;
        x=y;
        y=z;
        k++;
         cout << y;
    }
return 0;
}
