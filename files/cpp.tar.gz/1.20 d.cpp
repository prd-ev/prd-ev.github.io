#include <iostream>

using namespace std;

int main()
{
   int n,x=1,i,s=1;
    cout << "Podaj n: " << endl;
    cin  >> n;
    cout << "Ciag: " << endl;

     for (i=1;i<=n;i++)
    {
         cout << x << endl;
         x=x*(-2) ;
         s=s*x;
    }

     cout << s;
}
