#include<iostream>
using namespace std;
int main()
{
    int i=1,n,ujemne=0,dodatnie=0;
    while (i<=10)
    {
        cin>>n;
        if (n<0)
        {
            ujemne=ujemne+1;
        }
        else
        {
            dodatnie+=1;
        }
        i+=1;
    }
    cout<<"dodatnia="<<dodatnie;
    cout<<" "<<"ujemne="<<ujemne;
}
