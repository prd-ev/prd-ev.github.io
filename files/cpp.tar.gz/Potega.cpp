#include <iostream>

using namespace std;

int main()
{
    int x,n,k=1,i=0;

    cout << "Podaj podstawe potegi: ";
    cin  >> n;
    cout << "podaj wyjk�adnik potegi: ";
    cin  >> x;
     if (n==0 && x==0)
        cout << "Taka potega nie istnieje!" ;
    else
        while(i!=x)
    {
      k=k*n;
      i+=1;
    }
    cout << "Potega:" << k;






    return 0;
}
