#include <iostream>

using namespace std;

int main()
{
    float n;
    cin >> n;
    float up = 1, down = 1;
    float i = 1;
    while(i <= n){
        up *= 2 + (i * 0.5);
        i++;
    }
    cout << up;
    return 0;
}