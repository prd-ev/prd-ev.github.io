#include <iostream>

using namespace std;

int main()
    {
        cout << "Podaj 2 liczby: ";
        float liczba, liczba2;
        cin >> liczba;
        cin >> liczba2;
        float max;

        liczba > liczba2 ? max = liczba : max = liczba2;
        cout << max;

        return 0;
    }
