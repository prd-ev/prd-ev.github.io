#include <iostream>
using namespace std;
int main()
{
    int n, a = 1;
    double iloczyn = 1;
    cout<<"podaj n=";
    cin>>n;
    while (a <= n)
    {
        iloczyn *= (a+3)/n;
        a++;
    }
    cout<<"Iloczyn="<<iloczyn;
    return 0;
}
