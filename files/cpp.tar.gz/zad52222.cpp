#include<iostream>
using namespace std;
int main()
{
    int n,licznik=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        if (n%i==0)
        {
            licznik=licznik+1;
        }
    }
    if (licznik==2)
    {
        cout<<"tak";
    }
    else
    {
        cout<<"nie";
    }
}
