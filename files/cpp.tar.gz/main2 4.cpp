#include <iostream>

using namespace std;

int main()
{
    int i = 24;
    do{
        if (i % 4 != 0) {
            cout << i << endl;
        }
        i--;
    }
    while(i > 8);
    return 0;
}