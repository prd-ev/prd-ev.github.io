#include <iostream>

using namespace std;

int main()
{
    int x,s=0;
   cout<<"podaj liczbe";
   cin >> x;
   while(x>=0)
{

 x=x/10;
   s=s+1;}
cout << s;



    return 0;
}
