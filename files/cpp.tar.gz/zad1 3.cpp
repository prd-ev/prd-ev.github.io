#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    int n,i=1,suma=0;
    cin>>n;
    while (i<=n/2)
    {
        if (n%i==0)
        {
            suma=suma+i;
        }
        i=i+1;
    }
    if (suma==n)
    {
        cout<<"tak";
    }
    else
    {
        cout<<"nie";
    }
}
