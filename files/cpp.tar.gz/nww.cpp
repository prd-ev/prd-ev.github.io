#include <iostream>

using namespace std;

int main()
{
    int a,b,c,x;
    cout << "Podaj 2 liczby dodatnie:" << endl;
    cin  >> a;
    cin  >> b;
    x=a*b;
    while(b!=0)

    {
        if(a>b)
            a+=b;
        else
            b+=a;
    }
    cout << "Nww tych liczb to: " << x/a;


    return 0;
}
