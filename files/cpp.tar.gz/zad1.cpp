#include <iostream>

using namespace std;

int main()
{
    cout<<"Podaj pierwsza liczbe calkowita"<<endl;
    int a;
    cin>>a ;
    a%2==0 ? cout<<"Liczba parzysta" : cout<<"Liczba nieparzysta";
    return 0;
}
