#include <iostream>

using namespace std;
int n, s ;
int main()
{
    cout << "podaj n:" << endl;
    cin>> n;
    s=(n*(n+1))/2;
    if(n>=0)
        cout << s;
        else
        cout << n<0;
    return 0;
}
