#include <iostream>
using namespace std;
int main()
 {
float n,s;
cout << "podaj liczbe ciagu: " << endl ;
cin >> n;
s=(n*(n+1))/2 ;
cout << "liczba ciagu wynosi "<< s;




return 0;
  }
