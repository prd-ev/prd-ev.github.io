#include<iostream>
using namespace std;
int main()
{
    int i=65,n=90;
    while (i<=n)
    {
        cout<<(char)i;
        i+=1;
    }
    return 0;


}
