#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int n ,dzielnik=2;
    cout << "Podaj liczbe n>1 n= " << endl;
    cin  >> n;
    while(n%dziel
          nik!=0 && dzielnik<=sqrt(n))
    {dzielnik++;}
    if (dzielnik>sqrt(n)) cout << "\nPierwsza";
    else cout << "\nzlozona";




    return 0;
}
