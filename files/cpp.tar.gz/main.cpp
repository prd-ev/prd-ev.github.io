#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int n, i=2,suma=1;
    cout << "Podaj dowolna liczbe" << endl;
    cin>>n;
    int p=sqrt(n);
    while (i<=sqrt(n))
    {
        if (n%i==0)
            suma+=i+(n/i);
            i++;

    }
    if (n==p*p)
    suma-=p;
    cout<<"Suma: "<<suma<<endl;
    if (suma==n)
        cout<<"Liczba jest doskonala"<<endl;
    else
        cout<<"Liczba nie jest doskonala"<<endl;
    return 0;
}
