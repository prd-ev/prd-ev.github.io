#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
int a,s=0,m=0;

srand(time(NULL));
do
{
    a=2+rand()%49;
cout<<"a= " << a<<endl;
s+=a;
if(a>m)
m=a;
}
while(a%7);
{
 cout << "maksymalna liczba: " << m<<endl;
    cout << "suma= " << s<<endl;
}
    return 0;
}
