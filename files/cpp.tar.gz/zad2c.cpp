#include<iostream>
using namespace std;
int main()
{
    int i=1,n,w=1;
    cin>>n;
    while (i<=n)
    {
        w=w*i;
        i+=1;
    }
    cout<<w;
}
