#include<iostream>
using namespace std;
int main()
{
    int n,i,p,q,r,s;
    double k,l;
    cin>>n;
    i=2;
    p=-2;
    q=7;
    r=3;
    s=-7;
    do
    {
        k=p+q;
        p=p-10;
        q=q+10;
        l=r*s;
        r=r+8;
        s=s-8;
        i = i+1;
    }
    while (i<=n);
    cout<<k/l;
}
