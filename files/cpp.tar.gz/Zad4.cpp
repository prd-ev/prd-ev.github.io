#include <iostream>

using namespace std;

int main()
{
    cout << "podaj a i b: " << endl;


    double a,b,x;

    cin >> a >> b;



    if (a!=0) {
        x=-b/a;
        cout << "rozwiazaniem rownania jest: "  << x;
    }
    else {
        if (a==0&&b==0)
            cout << "Rownanie tozsamosciowe, nieskonczenie wiele rozw." ;
        else
        cout << "Rownanie sprzeczne, brak rozw." ;
        }

      return 0;
}

