#include<iostream>
using namespace std;
int main()
{
    int i=1,k=0,l=0,s=0;
    while (i<=9)
    {
        while (k<=9)
        {
            while (l<=9)
            {
                if (i!=k&&i!=l&&k!=l)
                    {
                    cout<<i<<k<<l<<' ';
                    s++;
                    }
                    l++;
            }
            l=0;
            k++;
        }
        k=0;
        i++;
    }

    cout<<"\n"<<"ilosc liczb z niepowtarzajacymi sie liczbami = "<<s;

}
