#include<iostream>
#include<iomanip>
using namespace std;

int main()
{

float kwota[] = { 12000.25, 1650000.75, 5200000, 190123 };
for( int i = 0; i < 4; i++ )
{
    cout << "Rachunek nr ";
    cout<<setw( 2 )<<setfill( '*' );
    cout << i << " opiewa na sume :";
    cout<<setw( 15 )<<setfill( '_' );
    cout << fixed<<setprecision(2)<<kwota[ i ] << " DM\n";
}
	return 0;
}
