#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int n, suma = 0;
    cin >> n;

    for(int i = 1; i <= n ; i++)
    {
        for(int j = 2; j <= sqrt(i) + 1; j++)
        {
            if(i==1)
            {
                break;
            }
            if(i==2)
            {
                suma += i
                break;
            }
            if(i%j==0)
            break;
        }
        suma += i;
    }

    cout << suma;

    return 0;
}
