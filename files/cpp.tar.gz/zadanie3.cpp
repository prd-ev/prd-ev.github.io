#include <iostream>

using namespace std;

int main()
{
    int n, suma = 0;
    cin >> n;

    for(int i = 1; i <= n; i++)
    {
        int suma_cyfr = 0;
        int ii = i;

        while(ii > 0)
        {
            suma_cyfr += ii % 10;
            ii /= 10;
        }

        if(suma_cyfr == 10)
        suma += i;
    }

    cout << suma;

    return 0;
}
