#include <iostream>

using namespace std;

int main()
{
     int n, i=1,s=0;
    cout << "Podaj n" << endl;
    cin>>n;

    while (i<=n)
    {
        if (i%100==31 || i%100==62 || i%100==17)
            s+=i;
        i++;

    }
    cout<<"Suma wynosi: "<<s<<endl;
    return 0;
}
