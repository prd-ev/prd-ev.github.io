#include <iostream>

using namespace std;

int main()
{
   int n,x=3,i;
    cout << "Podaj n: " << endl;
    cin  >> n;
    cout << "Ciag: " << endl;

     for (i=1;i<=n;i++)
    {
         cout << x << endl ;
         x=x*2 ;
    }





















return 0;
}
