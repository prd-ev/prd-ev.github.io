#include<iostream>
using namespace std;
int main()
{
    string a="*";
    int k=1;
    while (k <= 4)
        {
            cout<<a;
            if (k%2!=0)
            {
                cout<<"&&";
            }
            else
            {
                cout<<"^^";
            }
            a=a+"*";
            k=k+1;
        }
}
