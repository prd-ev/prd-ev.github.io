#include <iostream>

using namespace std;

int main()
{
    int n,x=2,y=0,k=1;

 cout << "Podaj n:" ;
 cin  >> n;

 while(k<=n)
 {
     if(x%2==0)
     y=y-x;
     else
     y=y+x;
x=x+3;
k++;
     }
     cout << y;
 }
















