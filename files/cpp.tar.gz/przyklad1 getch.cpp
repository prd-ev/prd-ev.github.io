#include <iostream>
#include <conio.h>
using namespace std;

int main() {
	cout << "\"";
	cout << endl;
	cout << "1\n2\n3\n4\n5\n";
	cout << endl;
	cout << "endl" << endl << "endl2";
	cout << endl;
	cout << ":( :)\r:)";
	cout << endl;
	cout << "Kolor Sztuk\nczarny 2\nzielony 3";
	cout << endl;
	cout << "Kolor\tSztuk\nczarny\t2\nniebieski\t3";
	cout << endl << endl;
	cout << "Wypisanie znaku \": \\\"";
	cout << endl;
	cout << ":( :)\r:)\n\n2015\t1\n2016\t2" << endl;
	getch();
	return 0;
}
