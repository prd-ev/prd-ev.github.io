#include <iostream>
using namespace std;

int main ()


{
    double i=1, k1=2,n, k2=-3, s1=1, s2=1;

    cout<<"Podaj ile wyrazow ma miec ciag"<<endl;
cin>>n;
do
{
   s1+=k1;
   k1+=0.5;
   s2*=0.1;
   i++;

}
while(i<=n);
cout<<"s = "<<(double)s1/s2<<endl;
return 0;
}
