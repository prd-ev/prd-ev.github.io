#include <iostream>

using namespace std;

int main()
{
    int x,y,i,s=0;
    cout<<"we podaj jaki� przedzia�: "<<endl;
    cin >>x;
    cin >>y;
    for(i=x;i<=y;i++)
    {
        s=s+i;
    }
    cout << s;







    return 0;
}
