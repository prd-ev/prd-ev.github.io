#include <iostream>

using namespace std;

int main()
{
    int x;
      for(int x=99;x<1000;x++)


{
if (x%2==0)
 cout << x << endl;

}















    return 0;
}
