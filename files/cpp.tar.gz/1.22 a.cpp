#include <iostream>

using namespace std;

int main()
{
int i=2;


while(i<=16)
    {
    if(i%3==0)
    cout<<i <<endl;
  i++;

}









    return 0;
}
