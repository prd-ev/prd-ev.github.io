#include <iostream>

using namespace std;

int main()
{
    int n,i=1;
    long s=1 , k=4;

 cout << "Podaj n:" ;
 cin  >> n;

 while(i<=n)
 {
if(k%2!=0) s-=k; else s*=-k;
k+=4;
i++;
     }
     cout << s;
 }









