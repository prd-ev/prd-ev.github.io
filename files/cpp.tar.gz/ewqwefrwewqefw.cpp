#include <iostream>

using namespace std;

const float pi = 3.1415;

main()
{

    cout << "Podaj r, h";
    float r, h, obj;
    cin >> r;
    cin >> h;

    obj = r*r*pi*h;

    cout << obj;

    return 0;
}
