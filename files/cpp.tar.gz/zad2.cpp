#include <iostream>

using namespace std;

int main()
{
    int a, b;
    double max;

    cout<< "Podaj pierwsza liczbe"<<endl;
    cin>> a ;
    cout<< "Podaj druga liczbe"<<endl;
    cin>> b;max= a>b ? a:b;
    cout<< "Wieksza z podanych liczb to: "<< max;
    return 0;
}
