#include <iostream>
#include <vector>

using namespace std;

int main() {
  int x, i = 0;
  vector <int> tab;
  cin >> x;

  while(x > 0) {
    tab.push_back(x % 2);
    x = x / 2;
    i++;
  }

  for(int o = i - 1; o >= 0; o--) {
    cout << tab[o];
  }
}
