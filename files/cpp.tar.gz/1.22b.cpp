#include <iostream>

using namespace std;

int main()
{
    int x=8;


     while(x<=24)
     {
         if(x%4!=0)
            cout <<x<<endl;
         x++;
     }












    return 0;
}
