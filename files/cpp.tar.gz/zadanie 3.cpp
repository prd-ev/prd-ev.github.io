#include <iostream>

using namespace std;

int main()
{
    cout << "Podaj n: ";
    int n;
    cin >> n;
    cout << (n>0) ? (n*n+1)/2 : 0;

    return 0;
}
