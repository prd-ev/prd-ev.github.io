#include <iostream>

int main()
{
    int n;
    std::cout << "Podaj liczb� n: ";
    std::cin >> n;

    if (n < 1)
    {
        std::cout << "Nie da sie";
    }
    else
    {
        std::cout << n*(n-1)/2;
    }

    return 0;
}
