#include <iostream>

using namespace std;

int main()
{
    cout << "Podaj wiek: " << endl;
    int wiek;
    cin >> wiek;

    wiek >= 18 ? cout << "Jeste� pe�noletni" : cout << "Nie jeste� jeszcze pe�noletni";


    return 0;
}
