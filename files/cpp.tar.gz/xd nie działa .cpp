#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{

int a,b,c,x;
srand(time(NULL));
a=rand()%(1001) ;
cout << "a= " <<a ;

b=rand()%(1001) ;
cout << "b= " <<b ;

c=+ rand()%(1001) ;
cout << "c= " <<c ;
a>b ? x=a : x=b ;
x>c ? cout<< "najwiesksza liczba to " << x=c <<x : cout<< "najwiesksza liczba to "<< x;





    return 0;
}
