#include<iostream>
using namespace std;
int main()
{
    int i,n,a,w;
    cin>>n>>i;
    if (i==0&&n==0)
    {
        return 0;
    }
    if (i==0)
    {
        cout<<1;
        return 0;
    }
    w=1;
    a=1;
    while (a<=i)
    {
        w = w*n;
        a=a+1;
    }
    cout<<w;
}
