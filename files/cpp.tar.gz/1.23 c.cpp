#include <iostream>
using namespace std;

int main ()


{
    int i=1, k=1,n, s=0;

    cout<<"Podaj ile wyrazow ma miec ciag"<<endl;
cin>>n;
do
{
    k*=i;
    s+=k;
    i++;

}
while(i<=n);
cout<<"s = "<<s<<endl;
return 0;
}
