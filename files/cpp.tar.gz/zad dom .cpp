#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{

int a,b,c,x;
srand(time(NULL));
a=rand()%(1001) ;
cout << "a=\n " <<a <<endl ;

b=rand()%(1001) ;
cout << "b=\n " <<b<<endl ;

c=+ rand()%(1001) ;
cout << "c=\n " <<c <<endl ;
a>b ? x=a : x=b ;

x>c ? x=a  : x=c ;
cout <<x <<endl ;






    return 0;
}
