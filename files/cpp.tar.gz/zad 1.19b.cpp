#include <iostream>

using namespace std;

int main()
{
    int x;
      for(int x=999;x>=100;x--)


{
if (x%2==0)
 cout << x << endl;

}















    return 0;
}
