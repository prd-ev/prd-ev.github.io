#include <iostream>

using namespace std;

int main()
{
    int n, i=1,s=0;
    cout << "Podaj n" << endl;
    cin>>n;

    while (i<=n)
    {
        if (i%10==1 || i%10==2 || i%10==7)
            s+=i;
        i++;

    }
    cout<<"Suma wynosi: "<<s<<endl;
    return 0;
}
