#include<iostream>
using namespace std;
int main()
{
    int i=1,n,licznik=0,ilo=1;
    while (ilo < 10000)
    {
    	cin>>n;
    	ilo=ilo*n;
    }
    cout<<ilo;
    return 0;
}
    
