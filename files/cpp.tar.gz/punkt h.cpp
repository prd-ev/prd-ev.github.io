#include <iostream>

using namespace std;

int main()
{
    int licz1,k=1,n,silnia,licz=1;
    double mian1=0, mian2=0,mian;
    cin>>n;
    do{
        licz1=n*n;
        silnia=1;
        for(int i=1;i<=k;i++){
            silnia*=i;
        }
        if(k%2==0){
            silnia*=-1;
        }
        licz*=licz1/silnia;

        mian1+=1;
        mian2+=3;
        cout<<licz<<" | "<<mian1/mian2<<endl;
        k++;
    }while(k<=n);

    mian = mian1/mian2;

    cout<<"Wynik: "<<licz/mian;

    return 0;
}
