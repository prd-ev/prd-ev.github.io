#include<iostream>
using namespace std;
int main()
{
    double n,p,i,q,suma;
    cin>>n;
    p=3;
    q=1;
    i = 1;
    do
    {
        suma=p*2./q;
        p=p+3;
        q+=1;
        i++;
    }
    while (i<=n);
    cout<<suma;

}
