#include <iostream>

using namespace std;

int main()
{
  int i;

for(i=0;i<=90;i++)
{
    cout<<(char)i<<endl;
}













    return 0;
}
