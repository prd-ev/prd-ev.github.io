#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
//podręcznik str.212-213

 //tutaj możesz zanotować
 double x=1234.555555, y=21.1234567812345678, w, z;

 //tutaj możesz zanotować
 cout<<"podaj dwie liczby rzeczywiste: "<<endl;

 //tutaj możesz zanotować
 cin>>w >>z;

 //tutaj możesz zanotować
 cout<<"\nx = "<<setw(12)<<x<<endl;

//tutaj możesz zanotować
 cout<<"\ny = "<<setfill('&')<<setw(15)<<y<<endl;

 //tutaj możesz zanotować
 cout<<"\ny = "<<setprecision(10)<<setfill('*')<<setw(12)<<y<<endl;

 //tutaj możesz zanotować
 cout<<"\nw = "<<setfill('0')<<setw(11)<<w<<endl;

 //tutaj możesz zanotować
 cout<<"\nz = "<<setfill('0')<<setw(16)<<z<<endl;

 //tutaj możesz zanotować
 cout<<"\nx + y + w = "<<setprecision(12)<<x+y+w<<endl;

 //tutaj możesz zanotować
 cout<<"\nx * z = "<<setprecision(7)<<x*z<<endl;

 return 0;
}
