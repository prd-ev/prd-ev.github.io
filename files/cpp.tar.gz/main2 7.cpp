#include <iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;
    float wynik = 0;
    int w = 1, i = 1;
    do{
        wynik += (6 * w)/i;
        w *= 2;
        i++;
    }
    while(i <= n);
    cout << wynik;
    return 0;
}