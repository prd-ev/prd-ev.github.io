#include <iostream>
#include <iomanip>
using namespace std;

int main()
{

int n;

cout << "Podaj liczbe: ";
cin >> n;
swich (n)
{
    case 1: n=sqrt(2*n) << cout n ; break

}





    return 0;
}
