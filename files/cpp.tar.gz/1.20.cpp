#include<iostream>
using namespace std;
int main()
{
    int n,i=-10,suma=0;
    cin>>n;
    while (i<=n)
    {
        suma=suma+i;
        i=i+6;
    }
    cout<<suma;
}
