#include<iostream>
using namespace std;
int main()
{
    int n,l=0;
    cin>>n;
    if (n==0)
    {
        cout<<1;
        return 0;
    }
    while (n>0)
    {
        l=l+1;
        n=n/10;
    }
    cout<<l;
}
