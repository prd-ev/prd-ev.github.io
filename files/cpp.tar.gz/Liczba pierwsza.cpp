#include <iostream>

using namespace std;

int main()
{
    int n,x=0,k=1,y=0;
    cout << "Podaj liczbe: " << endl;
    cin  >> n;
    if(n==k)
    {cout<<"Liczba nie jest pierwsza";}
    else {
        while(k<=n)
        {k++;x++;
        if(n%x==0)
{
    y++;
}
            }
    }


if(y<=2)
    cout<<"liczba jest pierwsza";
    else
    cout << "Liczba nie jest pierwsza";
    return 0;
}
