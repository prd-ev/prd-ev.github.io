#include <iostream>

using namespace std;

int main()
{
  int n,k,i=1,s=0;
  cout << "Podaj liczbe: " << endl;
  cin  >> n;

  do
  {
     if(n%i==0)
        s+=i;

      i++;
cout << s << endl;
  }
  while(i<=n/2);
if(s==n)
cout << "Liczbaq jest doskonala";
else
cout << "Liczba nie jest doskonala";



    return 0;
}
