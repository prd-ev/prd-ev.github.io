#include <iostream>
#include <cstdlib>
#include <ctime>


using namespace std;

int main()

    {
 double x,y,z;
 cout << "losowa liczba rzeczywista z zakresu [1,5; 2,25]" <<endl;
 srand(time(NULL));
 x = 1.5 +(double)rand()/RAND_MAX*(2.25-1.5);
 cout << x <<endl ;
 cout << "losowa liczba rzeczywista z zakresu [0; 1]" <<endl;
 y = 0 + (double)rand()/RAND_MAX;
 cout <<y <<endl;
 cout << "losowa liczba rzeczywista z zakresu [0; 64,5]" <<endl;
 z = 0 + (double)rand()/RAND_MAX*64.5;
 cout <<z <<endl;
return 0;
}








