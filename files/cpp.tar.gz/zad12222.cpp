#include<iostream>
using namespace std;
int main()
{
    int n,i=1,suma=0;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        if (i%10==1||i%10==2||i%10==7)
        {
            suma=suma+i;
        }
    }
    cout<<suma;
}
