#include<iostream>
using namespace std;
int main()
{
    int n,suma1=0,sumaw=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        int k=i;
        while (k>=1)
        {
            int x=k%10;
            suma1=suma1+x;
            k=k/10;
        }
        if (suma1%2==0)
        {
            sumaw=sumaw+suma1;
        }
        suma1=0;
    }
    cout<<sumaw;

}
