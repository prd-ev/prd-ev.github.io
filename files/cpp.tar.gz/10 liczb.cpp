#include <iostream>

using namespace std;

int main()
{

 int i=0 , x,u=0,n=0;

  while(i<=10)
  {
    cout << "podaj liczbe: ";
    cin >>x;

      if (x>=0)
        u=u+1;
        else
        n=n+1;
        i++;
        }
   cout << "ujemne= " << u<<endl;
  cout << "nieujemne= " << n<<endl;






    return 0;
}
