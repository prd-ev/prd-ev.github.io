#include <iostream>
#include <string.h>

using namespace std;

int main()
{

int n,x,suma,s=0,k;
    cout << "Podaj n" << endl;
    cin>>n;

    for (int i=1; i<=n; i++)

    {
        suma=0;
        k=i;
        while (k>=1)
        {
            x=k%10;
            k=k/10;
            suma+=x;
        }

        if (suma==10)
        {
            s+=i;
        }
    }

    cout<<"Suma wynosi: "<<s<<endl;
    return 0;
}
