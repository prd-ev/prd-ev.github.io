#include<iostream>
using namespace std;
int main()
{
    int i=1,n,licznik=0,ilo=1;
    while (ilo < 10000)
    {
    	cin>>n;
    	if (n != 0)
    	{
    		licznik = licznik + 1;
    	}
    	ilo=ilo*n;
    }
    cout<<licznik;
    return 0;
}
    