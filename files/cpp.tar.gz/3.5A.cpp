#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
int liczba;
srand(time(NULL));
liczba= 3 + rand()%(25-3+1) ;
cout << liczba << endl;




    return 0;
}
