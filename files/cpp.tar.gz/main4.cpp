#include <iostream>

using namespace std;

int main()
{
    int n, suma;
    cin >> n;
    suma = (1 + n) / 2 * n;
    cout << "Suma ciagu " << n << " kolejnych liczb naturalnych wynosi " << suma;
    return 0;
}
