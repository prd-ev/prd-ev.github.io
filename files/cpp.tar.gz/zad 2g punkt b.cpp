#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{
    int n=1,suma=0;
    srand(time(NULL));
    while (n%7!=0)
    {
    	n=2+rand()%(50-2+1);
    	suma = suma + n;
    }
    cout<<suma;
}
    
