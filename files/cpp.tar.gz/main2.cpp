#include <iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;
    int up1 = -2, up2 = 7;
    int down1 = 3, down2 = -7;
    int up = 0, down = 1;
    int i = 1;
    do{
        up += (up1 - (10 * i) + up2 + (10 * i));
        down *= ((down1 + (8 * i)) * (down - (8 * i)));
        i++;
    }
    while(i <= n/2);
    cout << up/down;
    return 0;
}