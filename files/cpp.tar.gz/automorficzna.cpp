#include <iostream>
#include <cmath>

using namespace std;

int main()
{
  int n, lc=0, d=10;
  cout << "Podaj liczbe naturalna n: ";
  cin >> n;
  int p=n*n;
  p-=n;
  do {
    lc++;
    n/=10;
  } while (n!=0);
  while (lc!=1) {
    d*=10;
    lc--;
  }
  if (p%d==0) {
    cout << "Liczba jest automorficzna" << endl;
  } else {
    cout << "Liczba nie jest automorficzna" << endl;
  }
  return 0;
}
