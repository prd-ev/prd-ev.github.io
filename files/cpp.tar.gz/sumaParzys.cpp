#include <iostream>

using namespace std;

int main()
{
   int suma=0,x=1,xrob=1,i=0,n;
   cout <<"Podaj liczbe: ";
   cin  >> n;
   while (i<=n)
 {
     int wynik=0;

     do
     {
      wynik=wynik+xrob%10;
      xrob=xrob/10;
     }
     while(xrob!=0);
     if(wynik%2==0){suma+=x;}
     i++;
     x++;
     xrob=x;

}
cout <<suma;
    return 0;
}
