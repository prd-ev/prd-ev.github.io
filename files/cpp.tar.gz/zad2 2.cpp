#include<iostream>
using namespace std;
int main()
{
    int n,i,licznik;
    cin>>n;
    i=2;
    licznik=0;
    while (n>1)
    {
        while (n%i==0)
        {
            licznik+=1;
            n=n/i;
        }
        if (licznik==0)
        {
            cout<<"";

        }
        else
        {
            cout<<i<<"^"<<licznik<<" ";
        }
        licznik=0;
        i=i+1;
    }
}
