#include <iostream>
using namespace std;
int main()
 {
  int  bok, pole;
   cout<<"Wprowadz dlugosc boku kwadratu bok = ";
	   cin>>bok;
	   pole = bok * bok;
   cout << "Pole kwadratu o boku "<< bok <<" wynosi "<<pole;
return 0;
  }
