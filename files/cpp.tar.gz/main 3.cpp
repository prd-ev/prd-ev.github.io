#include <iostream>

using namespace std;

int main()
{
    int a;
    cout << "Podaj dowolna liczbe calkowita" << endl;
    cin>>a;

    if (a%2==0)
        cout<<"liczba jest parzysta";
    else
        cout<<"liczba jest nieparzysta";

    return 0;
}
