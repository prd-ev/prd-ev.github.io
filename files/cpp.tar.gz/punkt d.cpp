#include<iostream>
using namespace std;
int main()
{
    double n,p,q,i,w;
    cin>>n;
    p=1;
    while (i<=n)
    {
        p = p+i;
        i = i+1;
    }
    q = 2;
    i = 6;
    while (i<=q)
    {
        q = q*i;
        i = i + 4;
    }
    w = p/q;
    cout<<w;
}
