#include<iostream>
using namespace std;
int main()
{
    int x,y,suma=0;
    cin>>x>>y;
    if (x>y||x<0||y<0)
    {
        cout<<"Blad danych";
        return 0;
    }
    while (x<=y)
    {
        suma= suma+x;
        x+=1;
    }
    cout<<suma;
}
