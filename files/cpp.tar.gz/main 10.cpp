#include <iostream>

using namespace std;

int main()
{
        int a,b,c;
    cout << "Podaj 3 dowolne liczby calkowite" << endl;
    cin>>a>>b>>c;
    if (a+b>c && b+c>a && c+b>a)
        cout<<"trojkat istnieje";
    else
        cout<<"trojkat nie istnieje";

    return 0;
}
