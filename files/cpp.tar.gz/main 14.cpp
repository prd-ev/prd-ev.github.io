#include <iostream>

using namespace std;

int main()
{
    float r;
    float dlugosc;
    cin >> r;
    dlugosc = r * 2 * 3.14
    cout << "Dlugosc wynosi" << dlugosc;
    return 0;
}
