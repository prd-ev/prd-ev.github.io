#include<iostream>
using namespace std;
int main()
{
    double n,k=1,p,q,w,i;
    cin>>n;
    i=1;
    p=2;
    q=-3;
    while (i<=n)
    {
        k =k*p;
        p = p + 0.5;
        i = i + 1;
        q = q*0.1;

    }
    w = k/q;
    cout<<w;
}
