#include <iostream>

int main()
{

    float a,b,c;
    std::cout << "Podaj 3 boki tr�jk�ta: ";
    std::cin >> a >> b >> c;

    if (a+b>c && b+c > a && c+a > b)
    {
        std::cout << "Tr�jk�t mo�e istnie�";
    }
    else
    {
        std::cout << "Tr�jk�t nie mo�e istnie�";
    }
    return 0;
}
