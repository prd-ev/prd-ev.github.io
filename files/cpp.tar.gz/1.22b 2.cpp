#include<iostream>
using namespace std;
int main()
{
    int n;
    n=24;
    do
    {
        if (n%4==0)
        {
            cout<<" "<<n;
        }
        n = n-1;
    }
    while (n>8);



}
