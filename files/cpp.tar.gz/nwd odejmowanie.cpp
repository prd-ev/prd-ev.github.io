#include <iostream>

using namespace std;

int main()
{ int a,b;
    cout << "Podaj 2 liczby: " << endl;
    cin >> a >> b;
    while(a!=b)
    {
        if(a>b)
        {
            a-=b;
        }
        else b-=a;
    }
cout << "Nwd dw�ch liczb jest: " << a;





    return 0;
}
