#include <iostream>

int main()
{
    float a, b;
    std::cout << "Rozwi�zujemy rownanie liniowe (ax + b = 0), podaj a,b:" << std::endl;
    std::cin >> a >> b;
    if (a==0)
    {
        if (b==0)
        {
            std::cout << "Niesko�czenie wiele rozwi�za�";
        }
        else
        {
            std::cout << "Nie ma rozwi�zania";
        }
    }
    else
    {
        std::cout << "x =:" << -b/a;
    }


    return 0;
}
