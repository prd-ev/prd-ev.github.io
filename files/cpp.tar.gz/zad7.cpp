#include<iostream>
using namespace std;
int main()
{
    int n,ilo=0,suma=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        for (int k=1;k<=i;k++)
        {
            if (i%k==0)
            {
                ilo=ilo+1;
            }
        }
        if (ilo==2)
        {
            suma=suma+i;
        }
        ilo=0;
    }
    cout<<suma;
}
