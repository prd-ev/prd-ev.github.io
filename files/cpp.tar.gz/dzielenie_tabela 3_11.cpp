#include <iostream>
using namespace std;
main()
{
 cout<<"9.0/2.0= "<<9.0/2.0<<endl;
 cout<<"9/2.0= "<<9/2.0<<endl;
 cout<<"9.0/2= "<<9.0/2<<endl;
 cout<<"9/2= "<<9/2<<endl;
 cout<<"9/2= "<<(double)9/2<<endl;
 return 0;
}
