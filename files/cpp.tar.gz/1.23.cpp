#include <iostream>
using namespace std;

int main ()


{
    int i=1, k=2,n, s=0;

    cout<<"Podaj ile wyrazow ma miec ciag"<<endl;
cin>>n;
do
{
if (i%2!=0) s-=k; else s+=k;
    k+=3;
    i++;

}
while(i<=n);
cout<<"s = "<<s<<endl;
return 0;


}
