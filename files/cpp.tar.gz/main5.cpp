#include <iostream>

using namespace std;

int main()
{
    int n, jednosci, dziesiatki, setki, tysiace;
    cin >> n;
    jednosci = n % 10;
    n = n/10;
    dziesiatki = n % 100;
    n = n/10;
    setki = n % 1000;
    n = n/10;
    tysiace = n % 10000;

    cout << tysiace << " tysiecy " << setki << " setek " << dziesiatki << " dziesiatek " << jednosci << " jednosci";
    return 0;
}
