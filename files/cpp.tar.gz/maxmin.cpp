#include <iostream>

using namespace std;

int main()
{
    int x,y,i=0,k;
  cout << "Podaj liczbe: ";
  cin >> k;
  x=k;
  y=k;

  do
{
 if(k>x)
    x=k;
 if(k<y)
    y=k;
  cout<<"podaj liczbe:";
  cin >> k;
  i++;
  }

  while(i!=9);

cout <<"najwieksza liczba: "<<x<<endl;
cout <<"najmniejsza liczba: "<<y<<endl;






    return 0;
}
