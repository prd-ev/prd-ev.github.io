#include <iostream>

using namespace std;

int main()
{
  int n;
  cin >> n;
  for(int i = 1; i <= n; i++) {
    for(int ik = 1; ik <= i; ik++) {
      cout << "*";
    }
    for(int ik = n; ik >= i; ik--) {
      cout << "|";
    }
    if(i % 2 == 0) {
      cout << "$$$$";
    } else {
      cout << "$$";
    }
  }
  return 0;
}
