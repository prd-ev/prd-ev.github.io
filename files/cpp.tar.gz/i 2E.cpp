#include <iostream>

using namespace std;
int n,s;
int main()
{
    cout << "Podaj liczbe n wienksza od zera" << endl;
    cin >> n ;
    n>0 ;
    s=(n*(n+1))/2 ;
    cout <<"wynik: "<< s;
    return 0;
}
