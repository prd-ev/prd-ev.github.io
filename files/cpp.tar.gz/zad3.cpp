#include <iostream>
using namespace std;
int main()
 {
float x;
cout << "podaj liczbe rozna od zaraz: " << endl  ;
cin  >> x;
cout << "odwortno�� tej liczby wynosi: " << 1/x;


return 0;
  }
