#include<iostream>
using namespace std;
int main()
{
    int n,i=1,niep=0,p=0;
    while (i<=20)
    {
        cin>>n;
        if (n<0)
        {
            niep+=1;
        }
        else
        {
            p+=1;
        }
        i+=1;
    }
    cout<<"nieparzyste="<<niep<<"\t"<<"parzyste="<<p;
}
