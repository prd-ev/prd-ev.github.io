#include <iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;
    float wynik = (n * (1 + n)) / 2;
    int i = 2;
    while(i <= 4*n){
        wynik /= i;   
        i += 4;
    }
    cout << wynik;
    return 0;
}