#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{
    int n=1,max=1;
    srand(time(NULL));
    while (n%7!=0)
    {
    	n=2+rand()%(50-2+1);
    	if (n>max)
    	{
    		max=n;
    	}
    }
    cout<<max;
}
    
