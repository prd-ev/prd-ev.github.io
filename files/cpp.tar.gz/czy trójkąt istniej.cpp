#include <iostream>

using namespace std;

int main()
{
int a ,b,c ;
cout << "podaj 3 liczby: "<<endl ;
cin  >> a;
cin  >> b;
cin  >> c;


{if (a<0 || b<0 || c<0)
cout << "b��d danych: ";
     else
{
    if (a>b&&a>c)
    {if(a<b+c)
      cout << "tr�rj�t istnieje";
      else cout<< " nie istnieje";}
      else
      {
        if (b>a&&b>c)
          {if(b<a+c)
          cout << "tr�rj�t istnieje";

          else
            cout<< " nie istnieje";}

}
{
    if (c>b &&c>a)
    {
        if (c<a+b)
            cout <<"istnieje" ;
        else
            cout <<"nie istnieje";
    }
}
}}


    return 0;
}
