#include <iostream>

using namespace std;

int main()
{
    float liczba, przeciwna;
    przeciwna = -liczba;
    cout << "Liczba przeciwna wynosi " << przeciwna;

    return 0;
}
