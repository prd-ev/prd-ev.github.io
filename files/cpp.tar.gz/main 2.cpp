#include <iostream>

using namespace std;

int main()
{
    int a;
    cout << "Podaj dowolna liczbe naturalna" << endl;
    cin>>a;
    a=a*(a+1)/2;
    cout<<a;

    return 0;
}
