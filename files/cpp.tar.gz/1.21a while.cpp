#include <iostream>

using namespace std;

int main()
{
    int n,s=0,i=1,q;
    cout << "podaj n " << endl;
    cin  >> n;
    while(i<=n)
    {
        s=s+i;
        cout<<s;
        i++;
    }
    q=2*n/s;










    return 0;
}
