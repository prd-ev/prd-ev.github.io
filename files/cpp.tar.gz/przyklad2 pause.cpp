#include <iostream>
#include <cstdlib>
using namespace std;

int main() {
	cout << "> Znaki specjalne <\nZnak\tKod\nnewline\t\\n\ntab\t\\t" << endl;
	system("pause");
	return 0;
}
