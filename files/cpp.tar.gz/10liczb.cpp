#include <iostream>

using namespace std;

int main()
{
    int i=0,nieu=0,uje=0,a;
   cout <<"podaj 10 liczb"<<endl;
   for(int i=1;i<=10;i++)
   {
       cin>>a;
       if(a>=0)
        nieu=nieu+1;
       if (a<0)
        uje=uje+1;
       ;
   }
   cout<<"ilosc ujemnych"<<uje<<endl;
   cout<<"ilosc nieujemnych"<<nieu<<endl;
    return 0;
}
