#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    //funkcja kwadratowa= ax^2+bx+c
    //delta= b^2*4*a*c
    double a,b,c,delta, x1,x2,x0;
    cout << "Podaj a "<< endl;
    cin>>a;
    cout<<"podaj b"<<endl;
    cin>>b;
    cout<<"podaj c"<<endl;
    cin>>c;

    if (a==0)
        cout<<"to nie jest funkcja kwadratowa";

    else
        delta=b*b-(4*a*c);

    if (delta>0)
    {


        x1=-b-sqrt(delta)/(2*a);
        x2=-b+sqrt(delta)/(2*a);

        cout<<"x1 rowna sie= "<<x1<<endl;
        cout<<"x2 rowna sie= "<<x2<<endl;

    }
        else if (delta==0)
{
    x0=-b/(2*a);
        cout<<"x0 rowna sie= "<<x0<<endl;
}
        else
        cout<<"brak miejsc zerowych";

    return 0;
}
