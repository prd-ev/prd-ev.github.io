#include <iostream>

using namespace std;

int main()
{
    int n,suma,k,s=0,x;
    cout << "Podaj n" << endl;
    cin>>n;

    for (int i=1; i<=n; i++)
    {
        suma=0;
        k=i;
        while (k>=1)
        {
           x=k%10;
           k/=10;
           suma+=x;
        if (suma%2==0)
           {
              s+=i;
           }
        }
    }
    cout<<"Suma wynosi: "<<s<<endl;

    return 0;
}
