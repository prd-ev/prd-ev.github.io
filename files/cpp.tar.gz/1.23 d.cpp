#include <iostream>
using namespace std;

int main ()


{
    int i=1, k=2,n, s1=0, s2=1;

    cout<<"Podaj ile wyrazow ma miec ciag"<<endl;
cin>>n;
do
{
    s1+=i;
    s2*=k;
    k+=4;
    i++;

}
while(i<=n);
cout<<"s = "<<(double)s1/s2<<endl;
return 0;
}
