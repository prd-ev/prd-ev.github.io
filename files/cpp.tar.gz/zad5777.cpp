#include<iostream>
using namespace std;
int main()
{
    int n,i=1,min=0,max=0;
    cin>>n;
    max=n;
    min=n;
    while (i<=9)
    {
        cin>>n;
        if (n>max)
        {
            max=n;
        }
        if (n<min)
        {
            min=n;
        }
        i+=1;
    }
    cout<<"najwieksza="<<max<<"\t"<<"najmniejsza="<<min;
}
