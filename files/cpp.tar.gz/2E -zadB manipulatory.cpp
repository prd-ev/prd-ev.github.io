#include <iostream>
#include <iomanip>

using namespace std;
int t=325;
int main()
{
//zadeklarowanie zmiennej t typu ca�kowitego i przypisanie jej warto�ci 325


//wy�wielenie warto�ci t
 cout << t << endl;

//wy�wietlenie napisu �konwersja systemow liczbowych:�
cout << "konwersja systemow liczbowych:"<< endl ;

//wy�wietlenie t w konwersji szesnastkowej
cout<<"szestnastkowy: " << hex << t<< endl;

 //wy�wietlenie t w konwersji dziesi�tnej
cout << "dziesientne: "<< dec << t<< endl;

 //wy�wietlenie t w konwersji szesnastkowej ze znakiem wype�nienia - i z szeroko�ci� pola 9
cout << "szesnatskowy: " << setfill('-') << setw(9) << hex << t << endl;

  //wy�wietlenie t w konwersji �semkowej ze znakiem wype�nienia ^ i z szeroko�ci� pola 14
cout << "osemkowy: "<<oct<< setfill('^') << setw(14) <<t<< endl;

 return 0;
}
