#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    srand(time(NULL));
    int a= rand()%11;
    int b= rand()%11;
    int c= rand()%11;
    cout<<"pierwsza liczba="<<a<<endl;
    cout<<"druga liczba="<<b<<endl;
    cout<<"trzecia liczba="<<c<<endl;
    cout<<"czy chociaz jedna liczba jest parzysta?"<<endl;
    cout<< (a%2==0||b%2==0||c%2==0? "TAK": "NIE")<<endl;



    return 0;
}
