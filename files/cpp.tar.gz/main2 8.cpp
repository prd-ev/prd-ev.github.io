#include <iostream>

using namespace std;

int main()
{
    int poprzedniaSilnia = 1;
    int n, wynik = 1, i = 2;

    cin >> n;
    while (i <= n)
    {
        poprzedniaSilnia *= i;
        wynik += poprzedniaSilnia;
        i++;
    }
    cout << wynik;
    return 0;
}