#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
    srand(time(NULL));

    int a= rand()%11;

    int b= rand()%11;

    int c= rand()%11;

    int d= rand()%11;

    cout<<"pierwsza liczba="<<a<<endl;
    cout<<"druga liczba="<<b<<endl;
    cout<<"trzecia liczba="<<c<<endl;
    cout<<"czwarta liczba="<<d<<endl;
    cout<<"czy sa mniejsze od 5?"<<endl;

    cout<<( (a<5&&b<5&&c<5&&d<5) ? "TAK" : "NIE")<<endl;


    return 0;
}
