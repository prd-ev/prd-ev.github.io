#include <iostream>

using namespace std;

int main()
{
    int licz=0,k=1,n,wynik;
    double mian=-0.5;
    cin>>n;

    do{
        wynik=1;
        if(k%2==0){
            for(int i=1;i<=k;i++){
                wynik*=i;
            }
            licz-=wynik;
        }
        else{
            for(int i=1;i<=k;i++){
                wynik*=i;
            }
            licz+=wynik;
        }
        mian+=0.3;
        cout<<licz<<" | "<<mian<<endl;
        k++;
    }while(k<=n);
    cout<<"Wynik: "<<licz/mian;

    return 0;
}
