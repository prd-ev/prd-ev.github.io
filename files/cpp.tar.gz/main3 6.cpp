#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    double a=123.666666666666;
    cout << (int) a <<endl;
    cout << setw(9) << a <<endl;
    cout << setfill('*') << setw(12) << a <<endl;
    cout << setprecision(8) << a <<endl;
    cout << setprecision(8) << setw(14) << setfill('0') << a <<endl;
    return 0;
}
