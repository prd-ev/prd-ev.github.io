#include <iostream>

using namespace std;

int main()

{
    int number;
    cout << "Podaj numer: ";
    cin >> number;
    cout << ((number%2==0) ? "Liczba parzysta" : "Liczba nieparzysta") << endl;
}
