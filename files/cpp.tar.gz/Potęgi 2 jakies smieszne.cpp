#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int n ,i,p;
    cout << "Poadaj n: " << endl;
    cin  >> n;
    i=0;
    p=1;
    while(i<n)
    {
        p=p*2;
         cout <<"Potega: "  << p << endl ;
         i++;

    }



















    return 0;
}
