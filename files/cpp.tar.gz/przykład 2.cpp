#include<iostream>
using namespace std;
int main()
{
    int i,k,l,s=0;
    for (i=1;i<=9;i++)
        for (k=0;k<=9;k++)
            for (l=0;l<=9;l++)
                if (i!=k&&i!=l&&k!=l)
                    {
                    cout<<i<<k<<l<<' ';
                    s++;
                    }
    cout<<"\n"<<"ilosc liczb z niepowtarzajacymi sie liczbami = "<<s;

}
