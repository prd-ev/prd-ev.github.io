#include<iostream>
using namespace std;
int main()
{
    long long int n,i=1,w;
    cin>>n;
    w=n*n;
    while (i<n)
    {
        i=i*10;
    }
    if (n==w%i)
    {
        cout<<"tak";
    }
    else
    {
        cout<<"nie";
    }
}
