#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
    int x;
    srand(time(NULL));
    menu:
    cout << "1. Dane ucznia" << endl;
    cout << "2. Aktualna data" << endl;
    cout << "3. Samodzielnie wybrany algorytm" << endl;
    cout << "4. Zakoncz" << endl;
    cout << "Twoj wybor: ";
    cin >> x;
    switch(x)
    {
case 1: cout << "Jakub Kowalewski" << endl;break;
case 2: cout << "17.12.2018" << endl;break;
case 3: cout << "Liczba losowa z zakresu 1-14: " << rand()%(15) << endl;break;
    }
    return 0;
}
