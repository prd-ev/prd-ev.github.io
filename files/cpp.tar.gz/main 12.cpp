#include <iostream>
#include <windows.h>
using namespace std;

int main()
{
    int n, i=2;
    cout << "Podaj dowolna liczbe wieksza od 0!" << endl;
    cin>>n;

    if (n==0)
        cout<<"to nie jest liczba pierwsza"<<endl;

        while (i<n)
    {
      if (n%i==0)
      {
        cout<<"to nie jest liczba pierwsza"<<endl;
      }

      else
        i++;

        if (i==n)
            cout<<"to jest liczba pierwsza"<<endl;

    }


    return 0;
}
