#include <iostream>

using namespace std;

int main()
{
    int n, suma = 0;
    cin >> n;

    for(int i = 1; i <= n; i++)
    {
        if(i % 10 == 1 || i % 10 == 2 || i % 10 == 7)
        suma += i;
    }

    cout << suma;

    return 0;
}
